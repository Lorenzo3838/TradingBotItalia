import numpy as np
import gymnasium as gym
from gymnasium import spaces

class SimpleTradingEnv(gym.Env):
    """
    Env long-only: azioni {0: hold, 1: buy, 2: sell/flat}.
    Stato: vettore feature + posizione (0/1). Reward: pnl giornaliero - commissioni quando cambia pos.
    """
    metadata = {"render_modes": []}

    def __init__(self, data, feature_cols, price_col="close", commission=0.0005, window=30):
        super().__init__()
        self.df = data.reset_index(drop=True)
        self.feature_cols = feature_cols
        self.price_col = price_col
        self.commission = commission
        self.window = window

        obs_size = len(self.feature_cols) + 1  # + posizione
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(obs_size,), dtype=np.float32)
        self.action_space = spaces.Discrete(3)  # hold/buy/sell(flat)

        self._reset_state()

    def _reset_state(self):
        self.t = self.window
        self.position = 0  # 0: flat, 1: long
        self.entry_price = 0.0
        self.equity = 1.0
        self.prev_price = float(self.df.loc[self.t-1, self.price_col])

    def _get_obs(self):
        feats = self.df.loc[self.t, self.feature_cols].astype(float).values
        obs = np.concatenate([feats, np.array([self.position], dtype=float)]).astype(np.float32)
        return obs

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        self._reset_state()
        return self._get_obs(), {}

    def step(self, action: int):
        assert self.action_space.contains(action)
        done = False
        reward = 0.0

        price = float(self.df.loc[self.t, self.price_col])

        # Commission only when position changes
        if action == 1:  # buy
            if self.position == 0:
                self.position = 1
                self.entry_price = price
                reward -= self.commission
        elif action == 2:  # sell/flat
            if self.position == 1:
                # realize pnl
                pnl = (price / self.entry_price - 1.0)
                reward += pnl - self.commission
                self.position = 0
                self.entry_price = 0.0
        else:
            # hold: if in position, daily floating pnl
            if self.position == 1:
                daily_ret = (price / self.prev_price - 1.0)
                reward += daily_ret

        self.prev_price = price
        self.t += 1
        if self.t >= len(self.df)-1:
            done = True

        obs = self._get_obs() if not done else np.zeros_like(self._get_obs())
        info = {}
        return obs, float(reward), done, False, info
