import pandas as pd
import numpy as np
import yfinance as yf
import ta

def download_data(symbol: str = "ENI.MI", period: str = "3y", interval: str = "1d") -> pd.DataFrame:
    """Scarica dati da Yahoo Finance (default: 3 anni, daily)."""
    df = yf.download(symbol, period=period, interval=interval, auto_adjust=True, progress=False)
    if df.empty:
        raise ValueError(f"Nessun dato scaricato per {symbol}.")
    df = df.rename(columns=str.lower)
    df.index = pd.to_datetime(df.index)
    return df

def make_features(df: pd.DataFrame, window: int = 30) -> pd.DataFrame:
    """Crea feature tecniche semplici e target (ritorno futuro)."""
    df = df.copy()
    # Indicatori classici
    df["rsi_14"] = ta.momentum.rsi(df["close"], window=14)
    macd = ta.trend.MACD(df["close"])
    df["macd"] = macd.macd()
    df["macd_diff"] = macd.macd_diff()
    df["sma_10"] = df["close"].rolling(10).mean()
    df["sma_30"] = df["close"].rolling(30).mean()
    df["atr_14"] = ta.volatility.average_true_range(df["high"], df["low"], df["close"], window=14)
    # Ritorni
    df["ret_1"] = df["close"].pct_change()
    df["ret_w"] = df["close"].pct_change(window)
    # Target: ritorno prossimo giorno
    df["future_ret"] = df["close"].pct_change().shift(-1)
    df = df.dropna().copy()
    return df

def train_val_split(df: pd.DataFrame, val_ratio: float = 0.2):
    n = len(df)
    split = int(n * (1 - val_ratio))
    train = df.iloc[:split].copy()
    val = df.iloc[split:].copy()
    return train, val
