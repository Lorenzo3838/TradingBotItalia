import os
import argparse
import pandas as pd
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.evaluation import evaluate_policy

from features import download_data, make_features, train_val_split
from env import SimpleTradingEnv

def make_env(df, commission=0.0005, window=30):
    feature_cols = [c for c in df.columns if c not in ["open","high","low","close","adj close","volume","future_ret"]]
    def _init():
        return SimpleTradingEnv(df, feature_cols=feature_cols, commission=commission, window=window)
    return _init

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", type=str, default=os.getenv("SYMBOL", "ENI.MI"))
    parser.add_argument("--commission", type=float, default=float(os.getenv("COMMISSION", "0.0005")))
    parser.add_argument("--window", type=int, default=int(os.getenv("WINDOW", "30")))
    parser.add_argument("--timesteps", type=int, default=int(os.getenv("TIMESTEPS", "40000")))
    args = parser.parse_args()

    print(f"[INFO] Downloading data for {args.symbol}")
    raw = download_data(args.symbol, period="3y", interval="1d")
    df = make_features(raw, window=args.window)

    train_df, val_df = train_val_split(df, val_ratio=0.2)

    train_env = DummyVecEnv([make_env(train_df, commission=args.commission, window=args.window)])
    val_env = DummyVecEnv([make_env(val_df, commission=args.commission, window=args.window)])

    print("[INFO] Training PPO...")
    model = PPO("MlpPolicy", train_env, verbose=1)
    model.learn(total_timesteps=args.timesteps)

    print("[INFO] Evaluating...")
    mean_reward, std_reward = evaluate_policy(model, val_env, n_eval_episodes=1, deterministic=True)
    print(f"[RESULT] mean_reward={mean_reward:.6f} ± {std_reward:.6f}")

    os.makedirs("models", exist_ok=True)
    save_path = os.path.join("models", "ppo_trading.zip")
    model.save(save_path)
    print(f"[INFO] Model saved at {save_path}")

if __name__ == "__main__":
    main()
